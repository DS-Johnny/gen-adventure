# from story_imaginator import StoryImaginator
# import os
# from dotenv import load_dotenv

# load_dotenv()

# imaginator = StoryImaginator(gemini_api_key = os.getenv("GEMINI_API_KEY"))

# print(imaginator.gemini_api_key)
# print(imaginator.model)

# imaginator.model = "gemini-3.5-flash"
# print(imaginator.model)

# imaginator.imagine("A small lizzard trying to drink water from a lake, a big bird is flying hunting him.", "lizzard.json")

# from google import genai

# client = genai.Client(
#     api_key="AQ.Ab8RN6IKGh8SCKc-MaL4nlYNBki705orKt2IIiNJnUo0cJjiRg"
# )

# print("cliente criado")

# response = client.models.generate_content(
#     model="gemini-2.5-flash",
#     contents="Say hello"
# )

# print(response.text)

from pages import Pages

pg = Pages('gen_adventure/love_story.json')

print(pg.get_options(1))